export const environment = {
  production: true,
  localStorageKey: 'auth',
  apiUrl: 'http://192.168.2.10:80/AirportFaresApi/api/v1',
  nameproduct: "Jacarandá Casa de Brincar"
};
