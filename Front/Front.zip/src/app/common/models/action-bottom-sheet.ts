export class ActionBottomSheet {
  icon: string;
  id: any;
  class: string;
  title: string;
  hidden: boolean = false;
  description: string;
  action: Function;
}