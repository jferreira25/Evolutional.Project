export class CEP {
    cep: string;
    logradouro: string;
    complemento:string;
    bairro:string;
    localidade:string;
    uf:string;
  }