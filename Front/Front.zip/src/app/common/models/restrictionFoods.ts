
  export class RestrictionFoods {
    id: number;
    name: string;
  }