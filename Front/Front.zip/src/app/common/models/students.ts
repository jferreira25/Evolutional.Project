export class Students {
    id: number;
    name: string;
    schoolGrades:number;
    lessonName:string;
  }