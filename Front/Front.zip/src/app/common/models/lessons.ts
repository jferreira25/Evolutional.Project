export class Lessons {
    id: number;
    name: string;
  }