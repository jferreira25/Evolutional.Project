export class DownloadResponse {
  dataToDownload: any;
  mimeType: string;
  fileName: string;
}