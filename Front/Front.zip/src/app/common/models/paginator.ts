export class Paginator<T> {
  total: number;
  list: T[];
}