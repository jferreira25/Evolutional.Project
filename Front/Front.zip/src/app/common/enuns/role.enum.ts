export enum RoleEnum {
  ADMIN = 1,
  APPROVER = 2,
  USER = 3
}