export enum TypeEnum {
  FLIGHT = 'Flight',
  EQUIPMENT = 'Equipment',
  EQUIPMENT_TYPE = 'EquipmentType'
}