﻿using MediatR;

namespace Evolutional.Project.Domain.Commands.Students.Generate
{
    public class GenerateStudentsCommand : IRequest
    {
    }
}
