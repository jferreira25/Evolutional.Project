﻿namespace Evolutional.Project.Domain.Dto
{
    public class StudentsLessonsDto
    {
        public string StudentName { get; set; }
        public long LessonId { get; set; }
        public decimal SchoolGrades { get; set; }
    }
}
