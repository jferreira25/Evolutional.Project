﻿namespace Evolutional.Project.Domain.Dto
{
    public class ExcelDto
    {
        public string Nome { get; set; }
        public string Materia1 { get; set; }
        public string Nota1 { get; set; }
        public string Materia2 { get; set; }
        public string Nota2 { get; set; }
        public string Materia3 { get; set; }
        public string Nota3 { get; set; }
        public string Materia4 { get; set; }
        public string Nota4 { get; set; }
        public string Materia5 { get; set; }
        public string Nota5 { get; set; }
        public string Materia6 { get; set; }
        public string Nota6 { get; set; }
        public string Materia7 { get; set; }
        public string Nota7 { get; set; }
        public string Materia8 { get; set; }
        public string Nota8 { get; set; }
        public string Materia9 { get; set; }
        public string Nota9 { get; set; }
        public decimal Media { get; set; }
    }
}
