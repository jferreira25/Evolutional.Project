﻿namespace Evolutional.Project.Domain.Entities
{
    public class Users
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
