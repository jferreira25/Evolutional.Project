﻿namespace Evolutional.Project.Domain.Entities
{
    public class Students
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public decimal SchoolGrades { get; set; }
        public string LessonName { get; set; }
    }
}
