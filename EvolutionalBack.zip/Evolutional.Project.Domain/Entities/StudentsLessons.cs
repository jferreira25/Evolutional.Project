﻿namespace Evolutional.Project.Domain.Entities
{
    public class StudentsLessons
    {
        public long StudentsId { get; set; }
        public long LessonsId { get; set; }
        public float SchoolGrades { get; set; }
    }
}
