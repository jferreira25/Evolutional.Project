﻿namespace Evolutional.Project.Domain.Entities
{
    public class Lesson
    {
        public string Name { get; set; }
        public long Id { get; set; }
    }
}
