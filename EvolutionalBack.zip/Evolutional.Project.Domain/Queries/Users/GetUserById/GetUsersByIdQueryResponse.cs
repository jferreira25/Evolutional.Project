﻿namespace Evolutional.Project.Domain.Queries.Users.GetUsersById
{
    public class GetUsersByIdQueryResponse
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string SchoolGrades { get; set; }
    }
}
