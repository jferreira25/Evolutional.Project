﻿using MediatR;

namespace Evolutional.Project.Domain.Queries.Students.ExportStudents
{
    public class ExportStudentsQuery : IRequest<ExportStudentsQueryResponse>
    {
      
    }
}
