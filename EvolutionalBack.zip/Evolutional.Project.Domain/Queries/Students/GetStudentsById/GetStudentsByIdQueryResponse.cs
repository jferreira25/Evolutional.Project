﻿namespace Evolutional.Project.Domain.Queries.Students.GetStudentsById
{
    public class GetStudentsByIdQueryResponse
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string SchoolGrades { get; set; }
    }
}
