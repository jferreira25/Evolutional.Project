﻿namespace Evolutional.Project.Domain.Queries.Lessons.GetLessonsById
{
    public class GetLessonsByIdQueryResponse
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
